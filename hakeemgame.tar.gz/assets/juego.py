import pygame
import math
import random
import sys
import asyncio

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("HAKEEM - Balloon Shooter")
clock = pygame.time.Clock()
FPS = 60

WHITE  = (255, 255, 255)
BLACK  = (0,   0,   0  )
YELLOW = (255, 220, 0  )
GRAY   = (150, 150, 150)
SKIN   = (255, 200, 150)
GROUND = (40,  120, 40 )
RED    = (210, 30,  30 )

BALLOON_COLORS = [
    (30,  100, 255),
    (210, 40,  40 ),
    (30,  30,  30 ),
    (50,  200, 50 ),
]

font_lg = pygame.font.SysFont("Arial", 36, bold=True)
font_md = pygame.font.SysFont("Arial", 24, bold=True)
font_sm = pygame.font.SysFont("Arial", 15, bold=True)

CHAR_X = WIDTH // 2
CHAR_Y = HEIGHT - 110


class Balloon:
    def __init__(self, color):
        self.x = float(random.randint(80, WIDTH - 80))
        self.y = float(-70)
        self.color = color
        self.radius = 32
        self.speed = random.uniform(1.8, 3.2)
        self.swing = random.uniform(0, math.pi * 2)
        self.swing_speed = random.uniform(0.02, 0.04)
        self.alive = True
        self.popping = False
        self.pop_timer = 0
        self.counted = False

    def update(self):
        if self.popping:
            self.pop_timer += 1
            if self.pop_timer > 18:
                self.alive = False
            return
        self.y += self.speed
        self.swing += self.swing_speed
        self.x += math.sin(self.swing) * 1.2

    def draw(self, surface):
        x, y = int(self.x), int(self.y)
        r = self.radius
        if self.popping:
            for i in range(8):
                angle = i * math.pi / 4
                dist = self.pop_timer * 4
                px = x + int(math.cos(angle) * dist)
                py = y + int(math.sin(angle) * dist)
                size = max(1, 10 - self.pop_timer // 2)
                pygame.draw.circle(surface, self.color, (px, py), size)
            return
        pygame.draw.ellipse(surface, self.color,
                            (x - r, y - int(r * 1.25), r * 2, int(r * 2.5)))
        shine = tuple(min(255, c + 90) for c in self.color)
        pygame.draw.ellipse(surface, shine,
                            (x - r // 2, y - int(r * 1.05), r, int(r * 0.55)))
        pygame.draw.circle(surface, self.color, (x, y + int(r * 1.25)), 5)
        pygame.draw.line(surface, GRAY,
                         (x, y + int(r * 1.25) + 5),
                         (x, y + int(r * 1.25) + 45), 2)

    def hit(self, mx, my):
        return math.hypot(mx - self.x, my - self.y) < self.radius * 1.3


def draw_character(surface, gun_angle):
    cx, cy = CHAR_X, CHAR_Y

    # medias rojas
    pygame.draw.rect(surface, RED,   (cx - 22, cy + 62, 19, 20))
    pygame.draw.rect(surface, RED,   (cx + 3,  cy + 62, 19, 20))
    # zapatos negros
    pygame.draw.ellipse(surface, BLACK, (cx - 28, cy + 74, 30, 14))
    pygame.draw.ellipse(surface, BLACK, (cx - 2,  cy + 74, 30, 14))
    # short blanco
    pygame.draw.rect(surface, (230, 230, 230), (cx - 25, cy + 28, 50, 36), border_radius=4)

    # camiseta blanca base (Peru)
    pygame.draw.rect(surface, WHITE, (cx - 30, cy - 12, 60, 47), border_radius=6)
    # franja diagonal roja (de hombro izq a cadera der)
    stripe_points = [
        (cx - 30, cy - 12),
        (cx - 2,  cy - 12),
        (cx + 30, cy + 35),
        (cx + 4,  cy + 35),
    ]
    pygame.draw.polygon(surface, RED, stripe_points)
    # borde de la camiseta
    pygame.draw.rect(surface, (200, 200, 200), (cx - 30, cy - 12, 60, 47), 2, border_radius=6)

    # numero 7
    n7 = font_lg.render("7", True, RED)
    surface.blit(n7, (cx + 2, cy - 8))
    # nombre HAKEEM
    nm = font_sm.render("HAKEEM", True, BLACK)
    surface.blit(nm, (cx - nm.get_width() // 2, cy + 22))

    # brazo izquierdo
    pygame.draw.rect(surface, SKIN, (cx - 44, cy - 8, 16, 36), border_radius=6)
    # cabeza
    pygame.draw.circle(surface, SKIN, (cx, cy - 38), 30)
    # pelo
    pygame.draw.ellipse(surface, BLACK, (cx - 30, cy - 68, 60, 36))
    # ojos
    pygame.draw.circle(surface, BLACK, (cx - 11, cy - 42), 4)
    pygame.draw.circle(surface, BLACK, (cx + 11, cy - 42), 4)
    pygame.draw.circle(surface, WHITE, (cx - 9,  cy - 44), 2)
    pygame.draw.circle(surface, WHITE, (cx + 13, cy - 44), 2)
    # sonrisa
    pygame.draw.arc(surface, BLACK,
                    (cx - 13, cy - 32, 26, 14),
                    math.pi, 2 * math.pi, 2)

    # brazo derecho + pistola
    arm_start = (cx + 30, cy - 8)
    arm_end_x = arm_start[0] + math.cos(gun_angle) * 36
    arm_end_y = arm_start[1] + math.sin(gun_angle) * 36
    pygame.draw.line(surface, SKIN, arm_start,
                     (int(arm_end_x), int(arm_end_y)), 13)
    gun_tip_x = arm_end_x + math.cos(gun_angle) * 32
    gun_tip_y = arm_end_y + math.sin(gun_angle) * 32
    pygame.draw.line(surface, (40, 40, 40),
                     (int(arm_end_x), int(arm_end_y)),
                     (int(gun_tip_x), int(gun_tip_y)), 9)
    pygame.draw.line(surface, GRAY,
                     (int(arm_end_x), int(arm_end_y)),
                     (int(gun_tip_x), int(gun_tip_y)), 5)

    return (int(gun_tip_x), int(gun_tip_y))


def draw_crosshair(surface, mx, my):
    pygame.draw.circle(surface, WHITE, (mx, my), 16, 2)
    for dx, dy in [(-22, 0), (22, 0), (0, -22), (0, 22)]:
        pygame.draw.line(surface, WHITE,
                         (mx + dx // 3, my + dy // 3),
                         (mx + dx, my + dy), 2)


async def main():
    stars = [(random.randint(0, WIDTH), random.randint(0, HEIGHT - 80))
             for _ in range(120)]

    score = 0
    missed = 0
    wave = 1
    balloons = []
    flashes = []
    spawn_queue = []
    spawn_timer = 0
    SPAWN_DELAY = 70
    game_over = False

    def new_wave():
        nonlocal spawn_queue, spawn_timer
        spawn_queue = [random.choice(BALLOON_COLORS) for _ in range(7)]
        spawn_timer = 0

    new_wave()
    pygame.mouse.set_visible(False)

    while True:
        clock.tick(FPS)
        mx, my = pygame.mouse.get_pos()
        gun_angle = math.atan2(my - (CHAR_Y - 8), mx - (CHAR_X + 30))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_over:
                    await main(); return
                if event.key == pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not game_over:
                ae_x = CHAR_X + 30 + math.cos(gun_angle) * 36
                ae_y = CHAR_Y - 8  + math.sin(gun_angle) * 36
                gt_x = ae_x + math.cos(gun_angle) * 32
                gt_y = ae_y + math.sin(gun_angle) * 32
                flashes.append([gt_x, gt_y, mx, my, 10])
                for b in balloons:
                    if b.alive and not b.popping and b.hit(mx, my):
                        b.popping = True
                        score += 10
                        break

        if not game_over:
            spawn_timer += 1
            if spawn_timer >= SPAWN_DELAY and spawn_queue:
                balloons.append(Balloon(spawn_queue.pop(0)))
                spawn_timer = 0

            for b in balloons:
                b.update()
                if not b.popping and not b.counted and b.y > HEIGHT + 10:
                    missed += 1
                    b.counted = True

            balloons = [b for b in balloons if b.alive or b.popping]

            if not spawn_queue and len(balloons) == 0:
                wave += 1
                SPAWN_DELAY = max(25, SPAWN_DELAY - 5)
                new_wave()

            if missed >= 5:
                game_over = True

        # DIBUJO
        screen.fill((15, 15, 55))
        for s in stars:
            pygame.draw.circle(screen, WHITE, s, 1)
        pygame.draw.rect(screen, GROUND, (0, HEIGHT - 55, WIDTH, 55))
        pygame.draw.rect(screen, (60, 150, 60), (0, HEIGHT - 60, WIDTH, 10))

        for b in balloons:
            b.draw(screen)

        new_flashes = []
        for f in flashes:
            if f[4] > 0:
                pygame.draw.line(screen, (255, 255, 80),
                                 (int(f[0]), int(f[1])),
                                 (int(f[2]), int(f[3])), 2)
                pygame.draw.circle(screen, (255, 200, 50),
                                   (int(f[2]), int(f[3])), f[4])
                f[4] -= 1
                new_flashes.append(f)
        flashes = new_flashes

        draw_character(screen, gun_angle)
        draw_crosshair(screen, mx, my)

        # HUD
        pygame.draw.rect(screen, BLACK, (0, 0, WIDTH, 48))
        screen.blit(font_md.render(f"Puntaje: {score}", True, YELLOW), (10, 10))
        wd = font_md.render(f"Ronda: {wave}", True, WHITE)
        screen.blit(wd, (WIDTH // 2 - wd.get_width() // 2, 10))
        md = font_md.render(f"Fallos: {missed}/5", True, (220, 80, 80))
        screen.blit(md, (WIDTH - md.get_width() - 10, 10))

        if game_over:
            ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 160))
            screen.blit(ov, (0, 0))
            t1 = font_lg.render("GAME OVER", True, (220, 50, 50))
            t2 = font_lg.render(f"Puntaje: {score}", True, YELLOW)
            t3 = font_md.render("Presiona R para reiniciar  |  ESC para salir", True, WHITE)
            screen.blit(t1, (WIDTH // 2 - t1.get_width() // 2, HEIGHT // 2 - 80))
            screen.blit(t2, (WIDTH // 2 - t2.get_width() // 2, HEIGHT // 2 - 20))
            screen.blit(t3, (WIDTH // 2 - t3.get_width() // 2, HEIGHT // 2 + 50))

        pygame.display.flip()
        await asyncio.sleep(0)


asyncio.run(main())
