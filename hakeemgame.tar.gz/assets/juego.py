import pygame
import math
import random
import sys
import asyncio

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("HAKEEM - Balloon Shooter")
clock = pygame.time.Clock()
FPS = 60

WHITE   = (255, 255, 255)
BLACK   = (0,   0,   0  )
YELLOW  = (255, 220, 0  )
GRAY    = (150, 150, 150)
SKIN    = (255, 200, 150)
RED     = (210, 30,  30 )
MUSTARD = (200, 160, 50 )

BALLOON_COLORS = [
    (30,  100, 255),
    (210, 40,  40 ),
    (30,  30,  30 ),
    (50,  200, 50 ),
]

font_lg = pygame.font.SysFont("Arial", 36, bold=True)
font_md = pygame.font.SysFont("Arial", 24, bold=True)
font_sm = pygame.font.SysFont("Arial", 15, bold=True)
font_xl = pygame.font.SysFont("Arial", 48, bold=True)

CHAR_X = WIDTH // 2
CHAR_Y = HEIGHT - 110


# ===================== GLOBO =====================
class Balloon:
    def __init__(self, color):
        self.x = float(random.randint(80, WIDTH - 80))
        self.y = float(-70)
        self.color = color
        self.radius = 32
        self.speed = random.uniform(1.8, 3.2)
        self.swing = random.uniform(0, math.pi * 2)
        self.swing_speed = random.uniform(0.02, 0.04)
        self.alive = True
        self.popping = False
        self.pop_timer = 0
        self.counted = False

    def update(self):
        if self.popping:
            self.pop_timer += 1
            if self.pop_timer > 18:
                self.alive = False
            return
        self.y += self.speed
        self.swing += self.swing_speed
        self.x += math.sin(self.swing) * 1.2

    def draw(self, surface):
        x, y = int(self.x), int(self.y)
        r = self.radius
        if self.popping:
            for i in range(8):
                angle = i * math.pi / 4
                dist = self.pop_timer * 4
                px = x + int(math.cos(angle) * dist)
                py = y + int(math.sin(angle) * dist)
                size = max(1, 10 - self.pop_timer // 2)
                pygame.draw.circle(surface, self.color, (px, py), size)
            return
        pygame.draw.ellipse(surface, self.color,
                            (x-r, y-int(r*1.25), r*2, int(r*2.5)))
        shine = tuple(min(255, c+90) for c in self.color)
        pygame.draw.ellipse(surface, shine,
                            (x-r//2, y-int(r*1.05), r, int(r*0.55)))
        pygame.draw.circle(surface, self.color, (x, y+int(r*1.25)), 5)
        pygame.draw.line(surface, GRAY,
                         (x, y+int(r*1.25)+5), (x, y+int(r*1.25)+45), 2)

    def hit(self, mx, my):
        return math.hypot(mx-self.x, my-self.y) < self.radius * 1.3


# ===================== OVNI =====================
class UFO:
    def __init__(self):
        self.x = float(random.randint(100, WIDTH-100))
        self.y = float(-80)
        self.speed = random.uniform(1.0, 2.0)
        self.swing = random.uniform(0, math.pi*2)
        self.swing_speed = random.uniform(0.02, 0.03)
        self.alive = True
        self.popping = False
        self.pop_timer = 0
        self.counted = False
        self.light_timer = 0

    def update(self):
        if self.popping:
            self.pop_timer += 1
            if self.pop_timer > 25:
                self.alive = False
            return
        self.y += self.speed
        self.swing += self.swing_speed
        self.x += math.sin(self.swing) * 2.0
        self.light_timer += 1

    def draw(self, surface):
        x, y = int(self.x), int(self.y)
        if self.popping:
            cols = [(255,150,0),(0,255,100),(200,0,255)]
            for i in range(12):
                angle = i * math.pi / 6
                dist = self.pop_timer * 5
                px = x + int(math.cos(angle)*dist)
                py = y + int(math.sin(angle)*dist)
                size = max(1, 12-self.pop_timer//2)
                pygame.draw.circle(surface, cols[i%3], (px,py), size)
            return
        # base del platillo
        pygame.draw.ellipse(surface, (110,110,140), (x-50,y-12,100,26))
        pygame.draw.ellipse(surface, (150,150,180), (x-40,y-9, 80,18))
        # cupula
        pygame.draw.ellipse(surface, (80,200,100), (x-25,y-34,50,32))
        pygame.draw.ellipse(surface, (140,230,150), (x-16,y-28,28,20))
        # alien adentro
        pygame.draw.circle(surface, (60,190,60), (x, y-20), 11)
        pygame.draw.circle(surface, BLACK, (x-4,y-23), 3)
        pygame.draw.circle(surface, BLACK, (x+4,y-23), 3)
        pygame.draw.arc(surface, BLACK, (x-5,y-16,10,7), math.pi, 2*math.pi, 1)
        # antenas
        pygame.draw.line(surface, (60,190,60), (x-8,y-31),(x-14,y-42),2)
        pygame.draw.circle(surface, (255,255,0),(x-14,y-42),3)
        pygame.draw.line(surface, (60,190,60), (x+8,y-31),(x+14,y-42),2)
        pygame.draw.circle(surface, (255,255,0),(x+14,y-42),3)
        # luces parpadeantes
        light_cols = [(255,255,0),(255,100,0),(0,200,255),(255,0,200),(0,255,0)]
        for i, lx in enumerate([-36,-18,0,18,36]):
            on = (self.light_timer//6 + i) % 2 == 0
            col = light_cols[i] if on else (40,40,40)
            pygame.draw.circle(surface, col, (x+lx, y+7), 5)
        # rayo tractor
        beam = pygame.Surface((34,45), pygame.SRCALPHA)
        pygame.draw.polygon(beam, (100,255,100,50), [(17,0),(0,45),(34,45)])
        surface.blit(beam,(x-17, y+13))

    def hit(self, mx, my):
        return math.hypot(mx-self.x, my-self.y) < 48


# ===================== HAKEEM =====================
def draw_hakeem(surface, gun_angle):
    cx, cy = CHAR_X, CHAR_Y
    pygame.draw.rect(surface, RED,   (cx-22,cy+62,19,20))
    pygame.draw.rect(surface, RED,   (cx+3, cy+62,19,20))
    pygame.draw.ellipse(surface, BLACK,(cx-28,cy+74,30,14))
    pygame.draw.ellipse(surface, BLACK,(cx-2, cy+74,30,14))
    pygame.draw.rect(surface, (230,230,230),(cx-25,cy+28,50,36),border_radius=4)
    pygame.draw.rect(surface, WHITE,(cx-30,cy-12,60,47),border_radius=6)
    pygame.draw.polygon(surface, RED,[(cx-30,cy-12),(cx-2,cy-12),(cx+30,cy+35),(cx+4,cy+35)])
    pygame.draw.rect(surface,(200,200,200),(cx-30,cy-12,60,47),2,border_radius=6)
    n7 = font_lg.render("7", True, BLACK)
    surface.blit(n7,(cx+2,cy-8))
    nm = font_sm.render("HAKEEM", True, BLACK)
    surface.blit(nm,(cx-nm.get_width()//2,cy+22))
    pygame.draw.rect(surface,SKIN,(cx-44,cy-8,16,36),border_radius=6)
    pygame.draw.circle(surface,SKIN,(cx,cy-38),30)
    pygame.draw.circle(surface,BLACK,(cx-11,cy-42),4)
    pygame.draw.circle(surface,BLACK,(cx+11,cy-42),4)
    pygame.draw.circle(surface,WHITE,(cx-9, cy-44),2)
    pygame.draw.circle(surface,WHITE,(cx+13,cy-44),2)
    pygame.draw.arc(surface,BLACK,(cx-13,cy-32,26,14),math.pi,2*math.pi,2)
    pygame.draw.line(surface,BLACK,(cx-16,cy-48),(cx-6,cy-46),2)
    pygame.draw.line(surface,BLACK,(cx+6, cy-46),(cx+16,cy-48),2)
    pygame.draw.ellipse(surface,(20,20,20),(cx-32,cy-72,64,26))
    pygame.draw.rect(surface,(20,20,20),(cx+18,cy-68,26,8),border_radius=3)
    pygame.draw.line(surface,(80,80,80),(cx-32,cy-59),(cx+18,cy-59),2)
    arm_start = (cx+30,cy-8)
    aex = arm_start[0]+math.cos(gun_angle)*36
    aey = arm_start[1]+math.sin(gun_angle)*36
    pygame.draw.line(surface,SKIN,arm_start,(int(aex),int(aey)),13)
    gtx = aex+math.cos(gun_angle)*32
    gty = aey+math.sin(gun_angle)*32
    pygame.draw.line(surface,(40,40,40),(int(aex),int(aey)),(int(gtx),int(gty)),9)
    pygame.draw.line(surface,GRAY,(int(aex),int(aey)),(int(gtx),int(gty)),5)
    return (int(gtx),int(gty))


# ===================== PERRITA SHIH TZU - TANA =====================
def draw_shitzu(surface, gun_angle):
    cx, cy = CHAR_X, CHAR_Y

    # patas traseras con pelito
    pygame.draw.rect(surface, MUSTARD, (cx-21,cy+30,18,52), border_radius=8)
    pygame.draw.rect(surface, MUSTARD, (cx+3,  cy+30,18,52), border_radius=8)
    pygame.draw.ellipse(surface, WHITE,  (cx-22,cy+28,18,14))
    pygame.draw.ellipse(surface, WHITE,  (cx+3, cy+28,18,14))
    # patitas redondeadas
    pygame.draw.ellipse(surface, WHITE,  (cx-28,cy+74,32,16))
    pygame.draw.ellipse(surface, WHITE,  (cx-4, cy+74,32,16))
    pygame.draw.ellipse(surface, MUSTARD,(cx-26,cy+76,14,10))
    pygame.draw.ellipse(surface, MUSTARD,(cx-2, cy+76,14,10))

    # cuerpo peludo
    pygame.draw.ellipse(surface, WHITE,  (cx-34,cy-20,68,60))
    # pelos decorativos cuerpo
    for px,py,pw,ph in [(cx-28,cy-15,18,22),(cx+10,cy-10,18,20),(cx-10,cy+5,20,18)]:
        pygame.draw.ellipse(surface, (240,240,240),(px,py,pw,ph))
    # manchas mostaza en cuerpo
    pygame.draw.ellipse(surface, MUSTARD,(cx-22,cy-8, 20,18))
    pygame.draw.ellipse(surface, MUSTARD,(cx+6,  cy+4, 16,14))
    pygame.draw.ellipse(surface, (220,180,70),(cx-8,cy-14,14,10))

    # collar TANA
    pygame.draw.rect(surface, (180,30,30),  (cx-28,cy-22,56,12), border_radius=6)
    pygame.draw.rect(surface, (220,50,50),  (cx-26,cy-21,52,10), border_radius=5)
    # hebilla dorada
    pygame.draw.circle(surface, YELLOW, (cx,cy-16), 6)
    pygame.draw.circle(surface, (200,160,0),(cx,cy-16), 4)
    tana_txt = font_sm.render("TANA", True, WHITE)
    surface.blit(tana_txt, (cx-tana_txt.get_width()//2, cy-21))

    # pata izquierda
    pygame.draw.ellipse(surface, WHITE,  (cx-50,cy-14,22,38))
    pygame.draw.ellipse(surface, MUSTARD,(cx-50,cy+16,22,14))

    # cabeza grande y redonda
    pygame.draw.circle(surface, WHITE,   (cx,cy-50), 36)
    # pelo lateral/orejas largas y sedosas
    pygame.draw.ellipse(surface, MUSTARD,(cx-52,cy-62,26,60))
    pygame.draw.ellipse(surface, (220,180,70),(cx-50,cy-58,18,50))
    pygame.draw.ellipse(surface, MUSTARD,(cx+26,cy-62,26,60))
    pygame.draw.ellipse(surface, (220,180,70),(cx+32,cy-58,18,50))
    # pelo encima de la cabeza (moño)
    pygame.draw.ellipse(surface, MUSTARD,(cx-14,cy-86,28,24))
    pygame.draw.ellipse(surface, (220,180,70),(cx-10,cy-84,20,18))
    # moñito rosado
    pygame.draw.ellipse(surface, (255,150,180),(cx-16,cy-90,14,10))
    pygame.draw.ellipse(surface, (255,150,180),(cx+2, cy-90,14,10))
    pygame.draw.circle(surface, (255,100,150),(cx,cy-88),5)

    # cara Shih Tzu
    pygame.draw.circle(surface, (240,215,190),(cx,cy-50),26)
    # ojos grandes brillantes
    pygame.draw.circle(surface, (30,20,10),  (cx-12,cy-56),8)
    pygame.draw.circle(surface, (30,20,10),  (cx+12,cy-56),8)
    pygame.draw.circle(surface, WHITE,        (cx-9, cy-59),4)
    pygame.draw.circle(surface, WHITE,        (cx+15,cy-59),4)
    pygame.draw.circle(surface, (200,240,255),(cx-10,cy-58),2)
    pygame.draw.circle(surface, (200,240,255),(cx+14,cy-58),2)
    # nariz chata y tierna
    pygame.draw.ellipse(surface, (180,100,100),(cx-8,cy-48,16,10))
    pygame.draw.ellipse(surface, (220,140,140),(cx-6,cy-47,12,7))
    # fosas
    pygame.draw.circle(surface, (140,60,60),(cx-4,cy-45),2)
    pygame.draw.circle(surface, (140,60,60),(cx+4,cy-45),2)
    # boca con sonrisa
    pygame.draw.arc(surface, (160,80,80),(cx-10,cy-42,20,12),math.pi,2*math.pi,2)
    # lengua
    pygame.draw.ellipse(surface,(230,90,90),(cx-6,cy-36,12,10))
    pygame.draw.line(surface,(200,70,70),(cx,cy-36),(cx,cy-31),2)
    # mejillas rosadas
    pygame.draw.circle(surface,(255,190,200),(cx-19,cy-47),6)
    pygame.draw.circle(surface,(255,190,200),(cx+19,cy-47),6)

    # pata derecha + pistola
    arm_start = (cx+34,cy-12)
    aex = arm_start[0]+math.cos(gun_angle)*36
    aey = arm_start[1]+math.sin(gun_angle)*36
    pygame.draw.line(surface,WHITE,arm_start,(int(aex),int(aey)),14)
    pygame.draw.ellipse(surface,MUSTARD,(int(aex)-10,int(aey)-6,20,12))
    gtx = aex+math.cos(gun_angle)*32
    gty = aey+math.sin(gun_angle)*32
    pygame.draw.line(surface,(40,40,40),(int(aex),int(aey)),(int(gtx),int(gty)),9)
    pygame.draw.line(surface,GRAY,(int(aex),int(aey)),(int(gtx),int(gty)),5)
    return (int(gtx),int(gty))


# ===================== FONDO NIVEL 1: MORRO DE ARICA =====================
def draw_morro(surface):
    surface.fill((100,180,255))
    for cx2,cy2 in [(120,60),(300,40),(550,70),(720,50)]:
        pygame.draw.ellipse(surface,WHITE,(cx2-40,cy2-15,80,30))
        pygame.draw.ellipse(surface,WHITE,(cx2-20,cy2-25,50,28))
    pygame.draw.rect(surface,(30,120,200),(0,HEIGHT-110,WIDTH//2,110))
    pygame.draw.rect(surface,(50,140,220),(0,HEIGHT-115,WIDTH//2,10))
    morro_pts = [
        (WIDTH//2-20,HEIGHT-55),(WIDTH//2+60,HEIGHT-200),
        (WIDTH//2+130,HEIGHT-320),(WIDTH//2+180,HEIGHT-380),
        (WIDTH//2+220,HEIGHT-350),(WIDTH//2+280,HEIGHT-260),
        (WIDTH,HEIGHT-180),(WIDTH,HEIGHT-55),
    ]
    pygame.draw.polygon(surface,(139,100,60),morro_pts)
    pygame.draw.polygon(surface,(160,120,75),[
        (WIDTH//2+130,HEIGHT-320),(WIDTH//2+160,HEIGHT-310),(WIDTH//2+180,HEIGHT-380)])
    fx,fy = WIDTH//2+175,HEIGHT-420
    pygame.draw.line(surface,(80,50,20),(fx,fy),(fx,fy+60),3)
    pygame.draw.rect(surface,(210,30,30),(fx,fy+30,50,30))
    pygame.draw.rect(surface,WHITE,(fx+18,fy,32,30))
    pygame.draw.rect(surface,(0,50,160),(fx,fy,18,30))
    for i in range(5):
        a1=math.pi/2+i*2*math.pi/5; a2=math.pi/2+(i+0.5)*2*math.pi/5
        pygame.draw.polygon(surface,WHITE,[
            (fx+9+int(math.cos(a1)*7),fy+15-int(math.sin(a1)*7)),
            (fx+9+int(math.cos(a2)*3),fy+15-int(math.sin(a2)*3)),
            (fx+9+int(math.cos(a1+2*math.pi/5)*7),fy+15-int(math.sin(a1+2*math.pi/5)*7)),
        ])
    pygame.draw.rect(surface,(200,180,130),(0,HEIGHT-55,WIDTH,55))
    pygame.draw.rect(surface,(180,160,110),(0,HEIGHT-60,WIDTH,10))
    lx,ly=WIDTH//2+40,HEIGHT-200
    pygame.draw.rect(surface,(240,220,160),(lx,ly,180,36),border_radius=4)
    pygame.draw.rect(surface,(100,70,30),(lx,ly,180,36),2,border_radius=4)
    pygame.draw.rect(surface,(100,70,30),(lx+87,ly+36,6,30))
    lt=font_sm.render("MORRO DE ARICA",True,(80,40,0))
    surface.blit(lt,(lx+90-lt.get_width()//2,ly+8))


# ===================== FONDO NIVEL 2: LINEAS DE NASCA =====================
def draw_nasca(surface):
    surface.fill((200,220,255))
    pygame.draw.rect(surface,(215,190,135),(0,HEIGHT//2-30,WIDTH,HEIGHT))
    # sol
    pygame.draw.circle(surface,(255,215,50),(680,65),38)
    for i in range(12):
        a=i*math.pi/6
        pygame.draw.line(surface,(255,195,30),(680+int(math.cos(a)*43),65+int(math.sin(a)*43)),(680+int(math.cos(a)*58),65+int(math.sin(a)*58)),2)
    # montanas
    pygame.draw.polygon(surface,(175,150,100),[(0,290),(80,210),(180,265),(320,185),(470,235),(620,175),(780,225),(800,290),(800,310),(0,310)])
    # suelo desierto
    pygame.draw.rect(surface,(215,190,135),(0,HEIGHT//2-30,WIDTH,HEIGHT))

    # --- ARAÑA DE NASCA ---
    ox,oy = 160,400
    pygame.draw.ellipse(surface,(90,65,35),(ox-18,oy-12,36,24),2)
    pygame.draw.ellipse(surface,(90,65,35),(ox-10,oy-26,20,16),2)
    legs=[
        [(-18,-4),(-40,-22),(-58,-12)],[(-18,0),(-42,-4),(-60,8)],
        [(-18,6),(-38,18),(-55,30)],[(-14,10),(-32,28),(-46,40)],
        [(18,-4),(40,-22),(58,-12)],[(18,0),(42,-4),(60,8)],
        [(18,6),(38,18),(55,30)],[(14,10),(32,28),(46,40)],
    ]
    for leg in legs:
        pts=[(ox+p[0],oy+p[1]) for p in leg]
        for i in range(len(pts)-1):
            pygame.draw.line(surface,(90,65,35),pts[i],pts[i+1],2)

    # --- COLIBRI DE NASCA ---
    bx,by=580,400
    pygame.draw.ellipse(surface,(90,65,35),(bx-28,by-10,56,18),2)
    pygame.draw.circle(surface,(90,65,35),(bx+32,by-2),9,2)
    pygame.draw.line(surface,(90,65,35),(bx+41,by-2),(bx+75,by-9),2)
    pygame.draw.ellipse(surface,(90,65,35),(bx-24,by-34,44,27),2)
    pygame.draw.line(surface,(90,65,35),(bx-28,by+2),(bx-58,by+14),2)
    pygame.draw.line(surface,(90,65,35),(bx-28,by+8),(bx-58,by+22),2)
    pygame.draw.line(surface,(90,65,35),(bx-5,by+9),(bx-5,by+28),2)
    pygame.draw.line(surface,(90,65,35),(bx+5,by+9),(bx+5,by+28),2)

    # lineas geometricas
    for lx2 in range(0,WIDTH,90):
        pygame.draw.line(surface,(175,150,100),(lx2,HEIGHT//2-10),(lx2+50,HEIGHT),1)

    pygame.draw.rect(surface,(190,165,110),(0,HEIGHT-55,WIDTH,55))
    pygame.draw.rect(surface,(175,150,95),(0,HEIGHT-60,WIDTH,10))

    # letrero
    lx,ly=20,HEIGHT-200
    pygame.draw.rect(surface,(240,220,160),(lx,ly,210,36),border_radius=4)
    pygame.draw.rect(surface,(100,70,30),(lx,ly,210,36),2,border_radius=4)
    pygame.draw.rect(surface,(100,70,30),(lx+102,ly+36,6,30))
    lt=font_sm.render("LINEAS DE NASCA",True,(80,40,0))
    surface.blit(lt,(lx+105-lt.get_width()//2,ly+8))


def draw_crosshair(surface,mx,my):
    pygame.draw.circle(surface,WHITE,(mx,my),16,2)
    for dx,dy in [(-22,0),(22,0),(0,-22),(0,22)]:
        pygame.draw.line(surface,WHITE,(mx+dx//3,my+dy//3),(mx+dx,my+dy),2)


async def main():
    level = 1
    hits  = 0
    missed = 0
    objects = []
    flashes = []
    spawn_queue = []
    spawn_timer = 0
    SPAWN_DELAY = 70
    game_over = False
    won = False
    transitioning = False
    transition_timer = 0
    TRANSITION_DURATION = 120  # 2 segundos a 60fps

    def setup_level(lv):
        nonlocal spawn_queue, spawn_timer, hits, missed, objects, flashes, SPAWN_DELAY
        objects=[]; flashes=[]; hits=0; missed=0; spawn_timer=0
        if lv==1:
            spawn_queue=[random.choice(BALLOON_COLORS) for _ in range(5)]
            SPAWN_DELAY=70
        else:
            spawn_queue=[1]*5
            SPAWN_DELAY=90

    setup_level(1)
    pygame.mouse.set_visible(False)

    while True:
        clock.tick(FPS)
        mx,my = pygame.mouse.get_pos()
        gun_angle = math.atan2(my-(CHAR_Y-8), mx-(CHAR_X+30))

        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_r and (game_over or won):
                    level=1; setup_level(1); game_over=False; won=False; transitioning=False; transition_timer=0
                if event.key==pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
            if event.type==pygame.MOUSEBUTTONDOWN and event.button==1 and not game_over and not won and not transitioning:
                aex=CHAR_X+30+math.cos(gun_angle)*36
                aey=CHAR_Y-8+math.sin(gun_angle)*36
                gtx=aex+math.cos(gun_angle)*32
                gty=aey+math.sin(gun_angle)*32
                flashes.append([gtx,gty,mx,my,10])
                for obj in objects:
                    if obj.alive and not obj.popping and obj.hit(mx,my):
                        obj.popping=True; hits+=1; break

        # transicion entre niveles
        if transitioning:
            transition_timer+=1
            if transition_timer>=TRANSITION_DURATION:
                transitioning=False; transition_timer=0
                level=2; setup_level(2)

        if not game_over and not won and not transitioning:
            spawn_timer+=1
            if spawn_timer>=SPAWN_DELAY and spawn_queue:
                if level==1:
                    objects.append(Balloon(spawn_queue.pop(0)))
                else:
                    spawn_queue.pop(0); objects.append(UFO())
                spawn_timer=0

            for obj in objects:
                obj.update()
                if not obj.popping and not obj.counted and obj.y>HEIGHT+10:
                    missed+=1; obj.counted=True

            objects=[o for o in objects if o.alive or o.popping]

            # nivel 1: si llega a 5 impactos inicia transicion
            if level==1 and hits>=5 and not transitioning:
                transitioning=True; transition_timer=0; objects=[]; spawn_queue=[]

            # nivel 2: si llega a 5 impactos gana
            if level==2 and hits>=5:
                won=True

            if missed>=3:
                game_over=True

        # DIBUJO
        if level==1:
            draw_morro(screen)
        else:
            draw_nasca(screen)

        for obj in objects:
            obj.draw(screen)

        new_flashes=[]
        for f in flashes:
            if f[4]>0:
                pygame.draw.line(screen,(255,255,80),(int(f[0]),int(f[1])),(int(f[2]),int(f[3])),2)
                pygame.draw.circle(screen,(255,200,50),(int(f[2]),int(f[3])),f[4])
                f[4]-=1; new_flashes.append(f)
        flashes=new_flashes

        if level==1:
            draw_hakeem(screen,gun_angle)
        else:
            draw_shitzu(screen,gun_angle)

        draw_crosshair(screen,mx,my)

        # HUD
        pygame.draw.rect(screen,BLACK,(0,0,WIDTH,48))
        screen.blit(font_md.render(f"Impactos: {hits}/5",True,YELLOW),(10,10))
        lv_t=font_md.render(f"Nivel: {level}/2",True,WHITE)
        screen.blit(lv_t,(WIDTH//2-lv_t.get_width()//2,10))
        md=font_md.render(f"Fallos: {missed}/3",True,(220,80,80))
        screen.blit(md,(WIDTH-md.get_width()-10,10))

        if level==2 and not won and not game_over:
            tip=font_sm.render("Nivel 2 — Dispara a los aliens!",True,(200,255,200))
            screen.blit(tip,(WIDTH//2-tip.get_width()//2,52))

        # MENSAJE HAPPY 420 durante transicion
        if transitioning:
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
            alpha=min(200, transition_timer*4)
            ov.fill((0,0,0,alpha)); screen.blit(ov,(0,0))
            scale=1.0+math.sin(transition_timer*0.15)*0.08
            t420=font_xl.render("Happy 420", True,(0,220,0))
            sw=int(t420.get_width()*scale); sh=int(t420.get_height()*scale)
            t420s=pygame.transform.scale(t420,(sw,sh))
            screen.blit(t420s,(WIDTH//2-sw//2, HEIGHT//2-sh//2))
            sub=font_md.render("Preparate para el nivel 2...",True,(180,255,180))
            screen.blit(sub,(WIDTH//2-sub.get_width()//2,HEIGHT//2+60))

        # GAME OVER — auto reinicio
        if game_over:
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
            ov.fill((0,0,0,170)); screen.blit(ov,(0,0))
            t1=font_xl.render("TODAVIA NO JOVEN",True,(220,50,50))
            secs=max(0,3-transition_timer//60)
            t3=font_md.render(f"Volviendo a empezar en {secs}...",True,WHITE)
            screen.blit(t1,(WIDTH//2-t1.get_width()//2,HEIGHT//2-60))
            screen.blit(t3,(WIDTH//2-t3.get_width()//2,HEIGHT//2+30))
            transition_timer+=1
            if transition_timer>=180:
                level=1; setup_level(1); game_over=False; transition_timer=0

        # GANASTE
        if won:
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
            ov.fill((0,0,0,180)); screen.blit(ov,(0,0))
            t1=font_xl.render("Ganaste, eres un OG !",True,YELLOW)
            t2=font_md.render("Presiona R para jugar de nuevo",True,WHITE)
            screen.blit(t1,(WIDTH//2-t1.get_width()//2,HEIGHT//2-60))
            screen.blit(t2,(WIDTH//2-t2.get_width()//2,HEIGHT//2+20))

        pygame.display.flip()
        await asyncio.sleep(0)


asyncio.run(main())
